Included is a sample PT5 and corresponding CD5 file.
You can open the PT5 via the Power Tool application to explore the features of the GUI.


Generated with PowerTool v 4.0.5.0. FW v 20.
